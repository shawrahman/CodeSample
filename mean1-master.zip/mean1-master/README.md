mean1
=====
Code archive for the book Full Stack JavaScript Development with MEAN
---------------------------------------------------------------------

This is really a good book (have a look at Sitepoint). However, cutting and pasting code from ebooks is tedious and prone to errors. 
You can find here some of the listing found in the book - they might have some modifications, though.



