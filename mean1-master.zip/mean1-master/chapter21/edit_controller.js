app.controller('edit', ['$scope', 'EmployeeService','$routeParams', function($scope, EmployeeService, $routeParams) {
  // See Listing 19-3 for complete code
}]);
