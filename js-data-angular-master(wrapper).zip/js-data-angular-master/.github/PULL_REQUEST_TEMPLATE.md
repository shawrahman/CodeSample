Fixes #<issue_number_goes_here> (it's a good idea to open an issue first for discussion)

- [ ] - `npm test` succeeds
- [ ] - Pull request has been squashed into 1 commit
- [ ] - I did NOT commit changes to `dist/`
- [ ] - Code coverage does not decrease (if any source code was changed)
- [ ] - Appropriate JSDoc comments were updated in source code (if applicable)
- [ ] - Approprate changes to js-data.io docs have been suggested ("Suggest Edits" button)
