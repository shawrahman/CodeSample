(delete this line) GitHub Issues are NOT for support questions.
(delete this line) GitHub Issues ARE for bug reports, feature requests, and other issues.
(delete this line) Find out how to Get Support here: http://js-data.io/docs/support.

<your detailed, discussable, actionable, and helpful text goes here>

Thanks!
